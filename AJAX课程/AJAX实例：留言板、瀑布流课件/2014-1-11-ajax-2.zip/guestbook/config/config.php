<?php
/**
 * @ config.php
 * @ zmouse@vip.qq.com
 */

$_CONFIGS = array(

	'db'	=>	array(
		'db_host'		=>	'localhost',
		'db_port'		=>	'3306',
		'db_user'		=>	'root',
		'db_password'	=>	'',
		'db_name'		=>	'miaov_guestbook',
	),

);