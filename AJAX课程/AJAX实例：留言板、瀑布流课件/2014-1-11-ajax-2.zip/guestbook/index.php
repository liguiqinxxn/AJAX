<?php
/**
 * @ index.php
 * @ zmouse@vip.qq.com
 */

define('IN_APP', TRUE);
//定义APP路径
define('APP_NAME', 'miaov_guestbook');
define('APP_PATH', dirname(__FILE__) . '/');

require(APP_PATH . 'libs/common.php');

